module LabAssignmentDay1 {
}