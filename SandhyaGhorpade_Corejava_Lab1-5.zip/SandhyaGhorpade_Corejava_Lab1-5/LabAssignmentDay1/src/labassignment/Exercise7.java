package labassignment;

import java.util.Scanner;

public class Exercise7 {
	private static Scanner tc=new Scanner(System.in);
	public static boolean checkNumber(int number) {
		boolean flag=false; 
		int c=0; 
		while(number >0) {  
			if(c>=number%10) { 
				flag=true;
				break;
			}
			else { 
				flag=false; 
				//return flag;
			}
			c=number%10;
			number=number/10;
		}
		return flag;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("ENTER THE NUMBER::");
		int n=tc.nextInt();
		boolean flag1=checkNumber(n);
		if(flag1==true) {
			System.out.println("INCREASING ORDER OF DIGITS OF NUMBER....");
		}
		else {
			System.out.println("DECREASING ORDER OF DIGITS OF NUMBER....");
		}
	}

}
