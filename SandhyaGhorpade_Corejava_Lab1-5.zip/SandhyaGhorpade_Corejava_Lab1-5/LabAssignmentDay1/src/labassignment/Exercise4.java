/*Write a Java program that prompts the user for an
 *  integer and then prints out all the prime numbers
 *   up to that Integer?*/

package labassignment;

import java.util.Scanner;

public class Exercise4 {
	
		public static void main(String[] args)
		{
			int m;
			int q;
			Scanner s=new Scanner(System.in);
			System.out.println("ENTER NUMBER: ");
			m=s.nextInt();
			for(int i=2;i<m;i++)
			{
				q=0;
				for(int j=2;j<i;j++)
				{
					if(i%j==0)
					q=1;
				}
				if(q==0)
					System.out.println(i);
			}
		}
	


}
