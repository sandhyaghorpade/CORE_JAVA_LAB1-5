
/*Write a java program that simulates a traffic
 *  light. The program lets the user select one of
 *   three lights: red, yellow, or green with radio 
 *   buttons. On entering the choice, an 
 *   appropriate message with �stop� or �ready� or
 *    �go� should appear in the console .Initially
 *     there is no message shown.*/
package labassignment;

import java.util.Scanner;

public class Exercise2 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("ENTER YOUR CHOICE:");
	    String choice = s.nextLine();
	   
	    switch (choice) {

	      case "Red":
	       System.out.println("STOP");
	        break;

	      case "Yellow":
	    	  System.out.println("READY");
		        break;

	      case "Green":
	    	  System.out.println("GO");
		        break;
	    }
	  }

}
