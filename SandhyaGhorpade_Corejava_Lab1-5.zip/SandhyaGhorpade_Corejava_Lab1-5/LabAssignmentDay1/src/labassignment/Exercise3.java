package labassignment;

import java.util.Scanner;

class Function
	{         
	     void nonrecfun(int a,int b,int c,int m)
	            {
	                        for(int i=1;i<=m-2;i++)
	                        {
	                                    c=a+b;
	                                    a=b;
	                                    b=c;
	                        }
	                        a=b=1;
	                        System.out.println("NTH VALUE IN THE SERIES USING NON RECURSIVE FUNCTION IS : "+c);
	                       
	            }
	            void  recfun(int a,int b,int c,int m)
	            {
	                                   
	                        if(m-2>0)
	                        {
	                                    c=a+b;
	                                    a=b;
	                                    b=c;
	                                    recfun(a,b,c,m-1);
	                                    return;
	                        }
	                       
	                        System.out.println("\nNTH VALUE IN THE SERIES USING  RECURSIVE FUNCTION IS : "+c);
	            }
	}
	           
class Exercise3
{
            public static void main(String args[])
            {
                        Function f=new Function();
                        int m,a=1,b=1,c=0;
                        Scanner scr=new Scanner(System.in);
                        System.out.println("ENTER THE VALUE:  ");
                        m=scr.nextInt();
                        f.nonrecfun(a,b,c,m);
                        f.recfun(a,b,c,m);
                       

            }
}

