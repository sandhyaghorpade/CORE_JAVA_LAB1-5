/*Create a method to find the sum 
 * of the cubes of the digits of an n digit
 *  number*/



package labassignment;

public class Exercise1 {
	public static int sumOfSeries(int n)
	{
		int s=0;
		for(int i=1;i<=n;i++)
			s +=i*i*i;
		return s;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
		System.out.println(sumOfSeries(n));

	}

}
