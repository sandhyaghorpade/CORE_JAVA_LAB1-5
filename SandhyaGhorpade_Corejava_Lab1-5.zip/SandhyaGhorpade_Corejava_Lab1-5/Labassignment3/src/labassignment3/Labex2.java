package labassignment3;
import java.util.*;
import java.util.Scanner;

public class Labex2 {
	
		
		// Function to reverse a string in Java using StringBuilder
		public static String rev(String s){
		return new StringBuilder(s).reverse().toString();
		}

		public static void main(String[] args){
			Scanner sc=new Scanner(System.in);
			System.out.println("ENTER INPUT STRING");
		String a= sc.next(); 
		String a1= rev(a);
		System.out.println("REVERSED STRING : "+a+"|"+a1);
		}
		}


