package labassignment3;

import java.util.Scanner;

public class Labex3 {
	 public String replaceConsonants(String str)
     {
            StringBuffer strbr = new StringBuffer(str);
            for(int i=0;i<str.length();i++)
            {
                   char t = strbr.charAt(i);
                   if(!(t == 'A' || t =='a' || t=='I'||t=='i'||t=='O'||t=='o'||t=='U'||t=='u'||t=='E'||t=='e'))
                   {
                         strbr.replace(i,i+1,String.valueOf((char)(t+1)));
                   }
            }
            return strbr.toString();
     }
     public static void main(String[] ar)
     {
    	 Labex3  g = new Labex3 ();
            Scanner sc = new Scanner(System.in);
            System.out.println("ENTER INPUT STRING..... ");
            String str = sc.next();
            System.out.println(g.replaceConsonants(str));
     }



}
