package labassignment3;

import java.util.Arrays;
import java.util.Scanner;

public class Labex8 {
	static boolean isAlphabaticOrder(String s)  
    {  
       
        int m = s.length();  
        char b[] = new char [m];  
         
        for (int i = 0; i < m; i++) {  
            b[i] = s.charAt(i);  
        }  
      
        Arrays.sort(b); 
        for (int i = 0; i < m; i++)  
            if (b[i] != s.charAt(i))   
                return false;  
                
        return true;      
    }  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);   
		System.out.print("ENTER THE INPUT STRING: ");  
		String s= sc.nextLine(); 
        if (isAlphabaticOrder(s))  
            System.out.println("....TRUE....");  
         else
             System.out.println("....FALSE....");  
             
	}

}


