package labassignment3;
import java.util.*;
public class Labex1 {
	
	
		    public static void main(String args[]) {
		        int m;
		        int sum = 0;
		        Scanner sc = new Scanner(System.in);
		        System.out.println("ENTER INTEGER (WITH ONE SPACE):");
		        String s = sc.nextLine();
		        StringTokenizer st = new StringTokenizer(s, " ");
		        while (st.hasMoreTokens()) {
		            String t = st.nextToken();
		            m = Integer.parseInt(t);
		            System.out.println(m);
		            sum = sum + m;
		        }
		        System.out.println("SUM IS ...... " + sum);
		       
		    }
		}


