package com.lab.tester;

import java.util.Scanner;

import com.lab.assign.Employee;

public class EmployeeTest {
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		EmployeeTest t = new EmployeeTest();
		
		try {
			System.out.println("Enter salary of employee");
			int salary = scanner.nextInt();
			if(salary<=3000) {
				throw new Employee("Salary can not be less than 300");
			}
			else {
				System.out.println("Salary accepted");
			}
		}catch(Exception e) {
			e.printStackTrace();
			//t.getMessage();
		}
		
	}
}
