package com.lab.tester;

import java.util.Scanner;

import com.lab.assign.Age;

public class AgeTest {
	private static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		try {
			System.out.println("Enter your age: ");
			int age= scanner.nextInt();
			if(age<15) {
				throw new Age("You are under-aged, cannot vote");
			}
			System.out.println("You are eligible to vote");

		}catch(Age e) {
		
			System.out.println("You are under-aged, cannot vote");
		}

	}
}
