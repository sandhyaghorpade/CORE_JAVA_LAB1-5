package com.lab.assign;

public class Name extends Exception {

	private String message;
	
	public Name() {
		
	}
	
	public Name(String message) {
		this.message=message;
	}
	
	public String getMessage() {
		return this.message;
	}
}
