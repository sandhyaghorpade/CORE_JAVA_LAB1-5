package com.lab.assign;


public class Employee extends Exception{

	private String message;
	
	
	public Employee() {
		
	}
	
	public Employee(String message) {
		this.message=message;
	}
	 
	public String getMessage() {
		return this.message;
	}
}
