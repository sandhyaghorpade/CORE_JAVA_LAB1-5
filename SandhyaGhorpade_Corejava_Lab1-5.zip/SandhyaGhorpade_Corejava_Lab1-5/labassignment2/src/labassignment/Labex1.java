/*Create a method which accepts an array of integer elements and return the second smallest element in the array

Note: Complete this exercise on Doselect.                     [DoSelect-Lab3_1]

Method Name 
getSecondSmallest 
Method Description 
Get the second smallest element in the array 
Argument 
int[] 
Return Type 
int 
Logic 
Sort the array and return the second smallest element in the array 

*/

package labassignment;

public class Labex1 {
	public static int getSecondSmallest(int[] a, int n){  
		int t;  
		for (int i = 0; i < n; i++)   
		        {  
		            for (int j = i + 1; j < n; j++)   
		            {  
		                if (a[i] > a[j])   
		                {  
		                    t = a[i];  
		                    a[i] = a[j];  
		                    a[j] = t;  
		                }  
		            }  
		        }  
		       return a[1]; 
		}  
		public static void main(String args[]){  
		int a[]={22,45,1,43,67,4};   
		System.out.println("SECOND LARGEST ELEMENT IS...... "+getSecondSmallest(a,6));  
		}}  


