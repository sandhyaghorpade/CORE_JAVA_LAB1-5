package com.cg.lab4.service.ex1;

public class CurrentAccount extends Account {
  private double overDraftLimit;
  
  public void withdraw(double amt)
	{
		if(amt<overDraftLimit)
		    System.out.println("U CAN WITHDRAW");
		else
			System.out.println("LIMIT REACHED...........");
		System.out.println("U CAN'T WITHDRAW...........");
		
	}
  
}
