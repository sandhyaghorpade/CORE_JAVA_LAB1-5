package com.cg.lab4.service.ex1;

public class SavingAccount extends Account {
	final double minBalance=1000;
	
	public SavingAccount(long accnum, double bal,Person p)
	{
		super(accnum,bal,p);
	}
	
	public void withdraw(double amt)
	{
		if(amt>minBalance)
		{
			System.out.println("CAN WITHDRAW");
		   setBalance(getBalance()-amt);
		}
		else
		{
			System.out.println("CANNOT WITHDRAW");
		}
	}
		

}
