package com.cg.lab4.ex3;



public class Book extends WrittenItem
{
	public Book(int idNum, String title, int numCopies, String author) {
		super(idNum, title, numCopies, author);
	}
}
