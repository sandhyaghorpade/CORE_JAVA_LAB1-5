package com.cg.eis.bean.lab4.ex2;

public enum Designation {
	ANALYST, FINANCER, CLERK, MANAGER;
}
