package com.cg.eis.service.lab4.ex2;

import java.util.Scanner;

import com.cg.eis.bean.lab4.ex2.Designation;
import com.cg.eis.bean.lab4.ex2.Employee;




public class EmployeeServiceImpl implements EmployeeService{
	
	public EmployeeServiceImpl(){
		
	}

	private static Scanner sc = new Scanner(System.in);
	@Override
	public void getEmployeeDetails(Employee emp) {
		
		System.out.println("EMPLOYEE DETAILS... ");
		
		System.out.println("EMPLOYEE ID... :");
		emp.setId(Integer.parseInt(sc.nextLine()));
		
		System.out.println("EMPLOYEE NAME... :");
		emp.setName(sc.nextLine());
		
		System.out.println("EMPLOYEE SALARY... :");
		emp.setSalary(Double.parseDouble(sc.nextLine()));
		
		System.out.println("DESIGNATION OF EMPLOYEE (ANALYST, FINANCER, CLERK, MANAGER)... :");
		String des = sc.nextLine();
		
		if(des.equalsIgnoreCase("Analyst"))
			emp.setDesignation(Designation.ANALYST);
		else if (des.equalsIgnoreCase("Financer"))
			emp.setDesignation(Designation.FINANCER);
		else if(des.equalsIgnoreCase("Clerk"))
			emp.setDesignation(Designation.CLERK);
		else if(des.equalsIgnoreCase("Manager"))
			emp.setDesignation(Designation.MANAGER);
	}

	@Override
	public String findInsuranceScheme(Employee emp) {
		
		// set insurance scheme based on designation and salary
		/*
		 * Salary				Designation			Insurance scheme
		 * >5000 and < 20000	Analyst          	Scheme C
		 * >=20000 and <40000	Financer			Scheme B
		 *	<5000          		Clerk			    Scheme A
		 *  >=40000				Manager				No Scheme
		 */
		
		Designation desig = emp.getDesignation();
		Double salary = emp.getSalary();
		String scheme = null;
		
		if(desig.equals(Designation.ANALYST) && (salary > 5000 && salary < 20000))
			scheme = "Scheme C";
		else if(desig.equals(Designation.FINANCER) && (salary >= 20000 && salary < 40000))
			scheme = "Scheme B";
		else if(desig.equals(Designation.CLERK) && (salary < 5000))
			scheme = "Scheme A";
		else if(desig.equals(Designation.MANAGER) && (salary > 40000))
			scheme = "No Scheme";
		
		emp.setInsuranceScheme(scheme);
		return scheme;
	}

	@Override
	public void showEmployeeDetails(Employee emp) {
		System.out.println("........................................................... :");
		System.out.println("DETAILS OF EMPLOYEE ARE... :");
		System.out.println(emp);
		
	}

}
