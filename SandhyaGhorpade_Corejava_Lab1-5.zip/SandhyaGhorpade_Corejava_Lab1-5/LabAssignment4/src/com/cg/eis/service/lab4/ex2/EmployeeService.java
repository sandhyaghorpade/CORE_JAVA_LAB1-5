package com.cg.eis.service.lab4.ex2;

import com.cg.eis.bean.lab4.ex2.Employee;

public interface EmployeeService {
	
	public abstract void getEmployeeDetails(Employee emp);
	public abstract String findInsuranceScheme(Employee emp);
	public abstract void showEmployeeDetails(Employee emp);
	
}
