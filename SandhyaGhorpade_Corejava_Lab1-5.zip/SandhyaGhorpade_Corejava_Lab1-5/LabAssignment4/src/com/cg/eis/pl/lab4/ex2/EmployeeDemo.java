package com.cg.eis.pl.lab4.ex2;

import com.cg.eis.bean.lab4.ex2.Employee;
import com.cg.eis.service.lab4.ex2.EmployeeService;
import com.cg.eis.service.lab4.ex2.EmployeeServiceImpl;

public class EmployeeDemo {

	public static void main(String[] args) {
		
		Employee e1 = new Employee();
		EmployeeService emp = new EmployeeServiceImpl(); 
		emp.getEmployeeDetails(e1);
		System.out.println("Insurance Scheme : "+emp.findInsuranceScheme(e1));
		emp.showEmployeeDetails(e1);
	}

}
