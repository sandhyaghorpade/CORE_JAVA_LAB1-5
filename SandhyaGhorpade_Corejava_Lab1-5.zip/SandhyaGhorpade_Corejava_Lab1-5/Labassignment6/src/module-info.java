module Labassignment6 {
}