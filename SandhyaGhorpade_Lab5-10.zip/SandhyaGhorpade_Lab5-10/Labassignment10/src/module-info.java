module Labassignment10 {
	requires java.desktop;
}