package com.cg.client.ex2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cg.server.ex2.FileDetails;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class FileDemo {

	public static void main(String rr[])throws IOException
	{
		FileDetails fd=new FileDetails();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the location of the file: ");
		String s=br.readLine();
		//FileInputStream f=new FileInputStream("D:\\FilePrgm.txt");
		FileDetails.analyze(s);
	}
}