module Labassignment7 {
}